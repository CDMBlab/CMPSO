%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function FitnessValue=LR(pts,class,factor)
snp_com=pts(:,factor)-1;
state=class'-1;
[xrow,xcol] = size(snp_com);
[Data,idx,cid]=unique(snp_com,'rows');
[lrow,~]=size(Data);

ua = unique(state);
if length(ua)~=2 
    disp(' Class state is not equal to 2 !!!');
elseif min(ua)>0
    state = state -min(ua);
end

Hcase = zeros(3,xcol);
Hcontrol = zeros(3,xcol);
sample=zeros(lrow,1);
disease=sample;
control=sample;

for i=1:xrow   %% 统计每个基因型组合出现的次数
   if state(i) == 1
       disease(cid(i)) = disease(cid(i)) + 1;
         for j = 1:xcol
              if snp_com(i,j) == 0
                  Hcase(1,j) = Hcase(1,j) + 1;
              elseif snp_com(i,j) == 1
                  Hcase(2,j) = Hcase(2,j) + 1; 
              else
                  Hcase(3,j) = Hcase(3,j) + 1;
              end
         end
   else
       control(cid(i)) = control(cid(i)) + 1;
        for j = 1:xcol
              if snp_com(i,j) == 0
                  Hcontrol(1,j) = Hcontrol(1,j) + 1;
              elseif snp_com(i,j) == 1
                  Hcontrol(2,j) = Hcontrol(2,j) + 1; 
              else
                  Hcontrol(3,j) = Hcontrol(3,j) + 1;
              end
         end
   end
end


%% G-test/LR
     F = [disease';control'];
     F(3,1:lrow)=sum(F(1:2,1:lrow),1);
     F(:,lrow+1)=sum(F(:,1:lrow),2);
     G=0;
     Degree=(2-1)*(lrow-1);
    for i=1:2
        for j=1:lrow
            O = F(i,j)/xrow;
            E = ( ( F(i,lrow+1) * F(3,j) )/xrow )/xrow;
              if F(3,j)>1
                   if O>0
                      G = G+(xrow * O) * log(O/E);
                   end
              elseif Degree>1
                 Degree = Degree-0.5; 
              end
        end    
    end

G=2*G;
%Gtest = 1/G;
LR = 1 / G;
FitnessValue=LR;
% FitnessValue=abs(z);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
