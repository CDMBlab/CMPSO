function MI=MutualInformation(pts,class,factor)
% Jan.19 2007 By Guoqiang Yu
% Compute Mutual Information between class label and a SNP set.计算类标签和SNP集之间的互信息
% % MI(X;C)=H(X)+H(C)-H(X,C), where C is the class label and X is a SNP set.
%--- INPUT
% data:  features x samples; note that the 样本特征
% value of zero indicates a missing data 值为0表示缺失数据
% labels: the label matrix of each sample;  每个样本的标签矩阵
%
%--- OUTPUT
% MI: Information provided by the features 特性提供的信息
%%
data=pts(:,factor);
data=double(data)';
class=double(class);
data=data-min(data(:));          %minimum data is 0
class=class-min(class(:))+1; %minimum label is 1

Num_Label=max(class(:));
Num_DataType=max(data(:))+1;
[Num_Feature,Num_Sample]=size(data);

%Entropy of the random variable Label 随机变量Label的熵
H_Label=hist(class,Num_Label);
P_Label=H_Label/Num_Sample;
Entropy_Label=-P_Label*log2(P_Label'+eps);

%Special dealing with the case of small Num_Feature 特殊处理小Num_Feature的情况
if Num_Feature<9
    ZZ=Num_DataType.^(Num_Feature-1:-1:0)';
    Hist_Label=zeros(Num_DataType^Num_Feature,Num_Label);%  Hist_Label is p(c,f)
    tempIndex=ZZ'*data+1;
    for j=1:Num_Sample
        Hist_Label(tempIndex(j),class(j))=Hist_Label(tempIndex(j),class(j))+1; % calculate p(c,f) 
    end
    
    sumHist=sum(Hist_Label,2);   %calculate p(f)
    repHist=repmat(sumHist,1,Num_Label); 
    pHist_Label=Hist_Label./(repHist+eps);%p(c/f)=p(c,f)/p(f).
    InfoIncre=-sum((log2(pHist_Label+eps).*pHist_Label).*(repHist));
    MI=Entropy_Label-sum(InfoIncre)/Num_Sample;
    MI=1./MI;
    return;
end

%Larger Feature Number follows the following procedure （大特征）遵循以下
mm=1;
Hist_Label=zeros(Num_Label,Num_Sample);
Hist_Label(class(1,1),mm)=1;
Hist_SNP=zeros(Num_Feature,Num_Sample);
Hist_SNP(:,mm)=data(:,1);

for j=2:Num_Sample
    tempData=data(:,j);
    Index=0;
    for k=1:mm
        if isequal(Hist_SNP(:,k),tempData)
            Index=k;
            break;
        end
    end
    if Index==0
        mm=mm+1;
        Hist_SNP(:,mm)=tempData;
        Hist_Label(labels(j,1),mm)=1;
    else
        Hist_Label(class(j,1),Index)=Hist_Label(class(j,1),Index)+1;
    end
end

M1=mm;
InfoIncre=0;
for s=1:M1
    tempNum=sum(Hist_Label(:,s));
    P=Hist_Label(:,s)/tempNum;
    InfoIncre=InfoIncre-P'*log2(P+eps)*tempNum;
end
MI=Entropy_Label-InfoIncre/Num_Sample;
MI=1./MI;
end
