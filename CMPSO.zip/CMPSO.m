function [solution, Time] = CMPSO(FileName,ParticleNumber,IterationNumber)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  [Result,Value,Time]=CMPSO('dat100',100,20)
MI=0;
filename=[FileName,'.mat'];
pardata=ParticleNumber;
Dimensions=2;
measure=4;
iteration=IterationNumber;

%% Time Begin
 tic

%% Input data
temp = load(filename);
pts = temp.pts;
class = temp.class;

%% Unimportant Parameters 
[~, snpdata] = size(pts);
% maximum particle position  
xmax = snpdata;
% minimum particle position 
xmin = 1;
% maximum particle velocity 
vmax = xmax;
% minimum particle velocity
vmin = - xmax;
% the acceleration coefficients controlling 
c1 = 0.25;
c2 = 0.25;
c3 = 0.25;
c4 = 0.25;
f1=2.05;
f2=2.05;
% inertia weight
W=0.65;

%% Initialize Parameters
%% initialize particle position 
par_x = cell(4,pardata);
par_mut = zeros(4,pardata);
Archive_x=cell(4,1);
Archive_mut = zeros(4,1);
Pareto_x=cell(4,pardata);
A_x=cell(4,1);
A_mut = zeros(4,1);
B_x=cell(iteration,4);
C_x=cell(iteration,4);
%% initialize particle velocity 
for i = 1:1:measure
    for j=1:1:pardata
        for z = 1:1:Dimensions
            par_x{i,j}(z) = round(1 + rand(1) * (xmax - 1) );
        end
         if par_x{i,j}(1) == par_x{i,j}(2)
               par_x{i,j}(2) = round(1 + rand(1) * (xmax - 1) ) ;
         end
            while i==1
                MI=MI+1;
                par_mut(i,j)= MutualInformation(pts, class,par_x{i,j});
                break;
            end
            while i==2
                par_mut(i,j)= BN(pts, class,par_x{i,j});
                break;
            end
            while i==3
                par_mut(i,j)= JS(pts, class,par_x{i,j});
                break;
            end
            while i==4
                par_mut(i,j)= LR(pts, class,par_x{i,j});
                break;
            end
    end
end

for  i = 1:1:measure
    for j=1:1:pardata
       par_x{i,j}= sort(par_x{i,j},2);
    end
end
%% initialize particle velocity 
par_v = cell(4, pardata);
for i = 1:1:measure
    for j = 1:1:pardata 
        for z = 1:1:Dimensions
            par_v{i,j}(z) = round(vmin + (vmax - vmin) * rand(1));
        end
    end
end

%% initialize individual optimal solution 
par_pbest_x = cell(4, pardata);
par_pbest_mut = zeros(4,pardata);
for i = 1:1:measure
    for j = 1:1:pardata
        par_pbest_x{i,j} = par_x{i,j};
        par_pbest_mut(i,j) = par_mut(i,j);
    end
end
%% Initialize the global optimal solution 
par_gbest_mut = zeros(4, 1);
par_gbest_x = cell(4, 1);
% index = cell(1, 4);
% max(par_pbest_mut,[],2);
         for i = 1:1:measure
            %     par_gbest_x{1,i}=par_pbest_x(index(i,1));
            [par_gbest_mut,index]=min(par_pbest_mut,[],2);
             par_gbest_x{i,1}=par_pbest_x{i,index(i,1)};
             Archive_x{i,1}=par_gbest_x{i,1};
             Archive_mut(i,1)=par_gbest_mut(i,1);
         
         end




%% Iteration
('Waitting...')

%% update particle velocity  
for t = 1:1:iteration  
    for j = 1:1:pardata
        for i = 1:1:measure  
            for z = 1:1:Dimensions                    

                     par_v{i,j}(z) = W *par_v{i,j}(z) + f1* rand(1) * (par_pbest_x{i,j}(z) - par_x{i,j}(z)) ...
                            +f2* rand(1) *(c1 * (Archive_x{1,1}(z)- par_x{i,j}(z))+c2  * (Archive_x{2,1}(z)- par_x{i,j}(z))...
                            +c3 * (Archive_x{3,1}(z)- par_x{i,j}(z))+c4 * (Archive_x{4,1}(z)- par_x{i,j}(z)));                 
                     par_v{i,j}(z) = round(par_v{i,j}(z));                    
            end             
        end
    end

%% update particle position 
     for j = 1:1:pardata   
        for i = 1:1:measure 
            for z = 1:1:Dimensions                
                par_x{i,j}(z) = par_x{i,j}(z) + par_v{i,j}(z);
                while z==2
                     if par_x{i,j}(1) == par_x{i,j}(2)
                           par_x{i,j}(2) = round(1 + rand(1) * (xmax - 1) ) ;
                     end
                     break
                end
                if par_x{i,j}(z) < xmin || par_x{i,j}(z) > xmax
                    par_x{i,j}(z) = xmin + round( ( xmax  - xmin) * rand(1) );
                end               
            end
            par_x{i,j}= sort(par_x{i,j},2);
%                 par_mut(i,j) = MutualInformation(pts,class,par_x{i,j});
            while i==1
                MI=MI+1;
                par_mut(i,j)= MutualInformation(pts,class,par_x{i,j});
                break;
            end
            while i==2
                par_mut(i,j)= BN(pts, class,par_x{i,j});
                break;
            end
            while i==3
                par_mut(i,j)= JS(pts, class,par_x{i,j});
                break;
            end
            while i==4
                par_mut(i,j)= LR(pts, class,par_x{i,j});
                break;
            end
        end  
    end
    
%% update individual optimal solution 
    for i = 1:1:measure
        for j = 1:1:pardata                
            if par_mut(i,j) < par_pbest_mut(i,j)
                par_pbest_mut(i,j) = par_mut(i,j);
                par_pbest_x(i,j) = par_x(i,j);
            end               
        end
    end


c=0;
     for j = 1:1:pardata     
        for i = 1:1:measure      
            if par_mut(i,j)<= Archive_mut(i,1)
                par_gbest_mut(i,1) = par_mut(i,j);
                par_gbest_x(i,1) = par_x(i,j);
                
                while i==1
                    if JS(pts,class,par_gbest_x{i,1})<=JS(pts,class,Archive_x{i,1}) && BN(pts,class,par_gbest_x{i,1})<=BN(pts,class,Archive_x{i,1}) && LR(pts,class,par_gbest_x{i,1})<=LR(pts,class,Archive_x{i,1})
                        if JS(pts,class,par_gbest_x{i,1})<JS(pts,class,Archive_x{i,1}) || BN(pts,class,par_gbest_x{i,1})<BN(pts,class,Archive_x{i,1}) || LR(pts,class,par_gbest_x{i,1})<LR(pts,class,Archive_x{i,1}) || par_mut(i,j)< Archive_mut(i,1)
                            Archive_x{i,1}=par_gbest_x{i,1};
                            Archive_mut(i,1)=par_gbest_mut(i,1);
                            B_x{t,i}=Archive_x{i,1};
%                               A_x{i,1}=par_gbest_x{i,1};
%                               A_mut(i,1)=par_gbest_mut(i,1);
                        else
                            c=c+1;
                            Pareto_x{i,c}= par_gbest_x{i,1};
                        end
                    else
                        c=c+1;
                        Pareto_x{i,c}= par_gbest_x{i,1};
                    end
                    break;
                end
                
                 while i==2
                     MI=MI+2;
                    if JS(pts,class,par_gbest_x{i,1})<=JS(pts,class,Archive_x{i,1}) && MutualInformation(pts,class,par_gbest_x{i,1})<=MutualInformation(pts,class,Archive_x{i,1}) && LR(pts,class,par_gbest_x{i,1})<=LR(pts,class,Archive_x{i,1})
                        if JS(pts,class,par_gbest_x{i,1})<JS(pts,class,Archive_x{i,1}) || BN(pts,class,par_gbest_x{i,1})<BN(pts,class,Archive_x{i,1}) || LR(pts,class,par_gbest_x{i,1})<LR(pts,class,Archive_x{i,1}) || par_mut(i,j)< Archive_mut(i,1)
                            Archive_x{i,1}=par_gbest_x{i,1};
                            Archive_mut(i,1)=par_gbest_mut(i,1);
                            B_x{t,i}=Archive_x{i,1};
%                               A_x{i,1}=par_gbest_x{i,1};
%                               A_mut(i,1)=par_gbest_mut(i,1);
                        else
                            c=c+1;
                            Pareto_x{i,c}= par_gbest_x{i,1};
                        end
                    else
                        c=c+1;
                        Pareto_x{i,c}= par_gbest_x{i,1};
                    end
                    break;
                 end
                 
                 while i==3
                     MI=MI+2;
                    if MutualInformation(pts,class,par_gbest_x{i,1})<=MutualInformation(pts,class,Archive_x{i,1}) && BN(pts,class,par_gbest_x{i,1})<=BN(pts,class,Archive_x{i,1}) && LR(pts,class,par_gbest_x{i,1})<=LR(pts,class,Archive_x{i,1})
                        if JS(pts,class,par_gbest_x{i,1})<JS(pts,class,Archive_x{i,1}) || BN(pts,class,par_gbest_x{i,1})<BN(pts,class,Archive_x{i,1}) || LR(pts,class,par_gbest_x{i,1})<LR(pts,class,Archive_x{i,1}) || par_mut(i,j)< Archive_mut(i,1)
                            Archive_x{i,1}=par_gbest_x{i,1};
                            Archive_mut(i,1)=par_gbest_mut(i,1);
                            B_x{t,i}=Archive_x{i,1};
%                               A_x{i,1}=par_gbest_x{i,1};
%                               A_mut(i,1)=par_gbest_mut(i,1);
                        else
                            c=c+1;
                            Pareto_x{i,c}= par_gbest_x{i,1};
                        end
                    else
                        c=c+1;
                        Pareto_x{i,c}= par_gbest_x{i,1};
                    end
                    break;
                 end
                 
                 while i==4
                        MI=MI+2;
                    if JS(pts,class,par_gbest_x{i,1})<=JS(pts,class,Archive_x{i,1}) && BN(pts,class,par_gbest_x{i,1})<=BN(pts,class,Archive_x{i,1}) && MutualInformation(pts,class,par_gbest_x{i,1})<=MutualInformation(pts,class,Archive_x{i,1})
                        if JS(pts,class,par_gbest_x{i,1})<JS(pts,class,Archive_x{i,1}) || BN(pts,class,par_gbest_x{i,1})<BN(pts,class,Archive_x{i,1}) || LR(pts,class,par_gbest_x{i,1})<LR(pts,class,Archive_x{i,1}) || par_mut(i,j)< Archive_mut(i,1)
                            Archive_x{i,1}=par_gbest_x{i,1};
                            Archive_mut(i,1)=par_gbest_mut(i,1);
                            B_x{t,i}=Archive_x{i,1};
%                               A_x{i,1}=par_gbest_x{i,1};
%                               A_mut(i,1)=par_gbest_mut(i,1);
                        else
                            c=c+1;
                            Pareto_x{i,c}= par_gbest_x{i,1};
                        end
                    else
                        c=c+1;
                        Pareto_x{i,c}= par_gbest_x{i,1};
                    end
                    break;
                 end
                 
               break; 
            end      
           C_x{t,i}=Archive_x{i,1};
        end
        
     end

A_x=Archive_x;
a_x=Archive_x;
A_mut=Archive_mut;
    for i = 1:1:measure
        while i==1
            for z = 1:1:1
                for j = 1:1:measure
                    A_x{1,1}(z)=Archive_x{j,1}(z);
                       MI=MI+2;
                        if MutualInformation(pts,class,A_x{1,1})<MutualInformation(pts,class,Archive_x{1,1})
                            a_x{1,1}=A_x{1,1};
                        end
                        
                end
            end
            break
        end
        while i==2
            for z = 1:1:1
                for j = 1:1:measure
                    A_x{2,1}(z)=Archive_x{j,1}(z);
                        if BN(pts,class,A_x{2,1})<BN(pts,class,Archive_x{2,1})
                            a_x{2,1}=A_x{2,1};
                        end 
                end
            end
            break
        end
        while i==3
            for z = 1:1:1
                for j = 1:1:measure
                    A_x{3,1}(z)=Archive_x{j,1}(z);
                        if JS(pts,class,A_x{3,1})<JS(pts,class,Archive_x{3,1})
                            a_x{3,1}=A_x{3,1};
                        end                      
                end
            end
            break
        end
        while i==4
            for z = 1:1:1
                for j = 1:1:measure
                    A_x{4,1}(z)=Archive_x{j,1}(z);
                        if LR(pts,class,A_x{4,1})<LR(pts,class,Archive_x{4,1})
                            a_x{4,1}=A_x{4,1};
                        end
                       
                end
            end
            break
        end
    end
    for  i = 1:1:measure
        while i==1
               MI=MI+2;
            if MutualInformation(pts,class,a_x{1,1})<MutualInformation(pts,class,Archive_x{1,1})
                            Archive_x{1,1}=a_x{1,1};
            end
            break
        end
        while i==2
            if BN(pts,class,a_x{2,1})<BN(pts,class,Archive_x{2,1})
                            Archive_x{2,1}=a_x{2,1};
            end
            break
        end
        while i==3
            if JS(pts,class,a_x{3,1})<JS(pts,class,Archive_x{3,1})
                            Archive_x{3,1}=a_x{3,1};
            end
            break
        end
       while i==4
            if LR(pts,class,a_x{4,1})<LR(pts,class,Archive_x{4,1})
                            Archive_x{4,1}=a_x{4,1};
            end
            break
        end
    end
    for  i = 1:1:measure
           Archive_x{i,1}= sort(Archive_x{i,1},2);       
    end

array_1=[Archive_x{1,1}(1),Archive_x{1,1}(2),Archive_x{2,1}(1),Archive_x{2,1}(2),Archive_x{3,1}(1),Archive_x{3,1}(2),Archive_x{4,1}(1),Archive_x{4,1}(2)];

count=max(array_1);
% tabulate(array_1(:));
Array=tabulate(array_1(:));
 array_2=[];
 sum=0;
for  i = 1:1:count
   if Array(i,2)>=4
%        array_2(1,i)=Array(i,1);
        sum=sum+1;
       array_2(1,sum)=Array(i,1);
   end
end
S=length(array_2);
array_3=cell(1,S);
for k=1:1:S
    for z=1:1:2
    array_3{1,k}(z)=array_2(k);
    end
end


m1=1;m2=1;m3=1;m4=1;
for i = 1:1:snpdata
    m=mod(i,4);
    if m==1
        modmatrix(1,m1)=i;
        m1=m1+1;
    end
    if m==2
        modmatrix(2,m2)=i;
        m2=m2+1;
    end
    if m==3
        modmatrix(3,m3)=i;
        m3=m3+1;
    end
    if m==0
        modmatrix(4,m4)=i;
        m4=m4+1;
    end
end
    
M1=1;M2=1;M3=1;M4=1;
N1=1;N2=1;N3=1;N4=1;

for j = 1:1:snpdata
    for k=1:1:S
        m=mod(j,4);
        while k==1 
            if m==1
                    array_3{1,1}(2)=modmatrix(1,M1);
                    M1=M1+1;
                       MI=MI+2;
                    if MutualInformation(pts,class,array_3{1,1})<MutualInformation(pts,class,Archive_x{1,1}) 
                         Archive_x{1,1}=array_3{1,1};
                    end
            end        
            if m==2
                    array_3{1,1}(2)=modmatrix(2,M2);
                    M2=M2+1;
                    if BN(pts,class,array_3{1,1})<BN(pts,class,Archive_x{2,1}) 
                                        Archive_x{2,1}=array_3{1,1};
                    end
            end           
            if m==3
                    array_3{1,1}(2)=modmatrix(3,M3);
                    M3=M3+1;
                    if JS(pts,class,array_3{1,1})<JS(pts,class,Archive_x{3,1}) 
                                    Archive_x{3,1}=array_3{1,1};
                    end
            end    
            if m==0
                    array_3{1,1}(2)=modmatrix(4,M4);
                    M4=M4+1;
                    if LR(pts,class,array_3{1,1})<LR(pts,class,Archive_x{4,1}) 
                                    Archive_x{4,1}=array_3{1,1};
                    end
            end                            
            break                   
         end

         while k==2             
             if m==1
                        array_3{1,2}(2)=modmatrix(1,N1);
                        N1=N1+1;
                           MI=MI+2;
                    if MutualInformation(pts,class,array_3{1,2})<MutualInformation(pts,class,Archive_x{1,1}) 
                                        Archive_x{1,1}=array_3{1,2};
                    end
             end
             if m==2
                    array_3{1,2}(2)=modmatrix(2,N2);
                    N2=N2+1;
                    if BN(pts,class,array_3{1,2})<BN(pts,class,Archive_x{2,1}) 
                                        Archive_x{2,1}=array_3{1,2};
                    end
             end
             if m==3
                    array_3{1,2}(2)=modmatrix(3,N3);
                    N3=N3+1; 
                    if JS(pts,class,array_3{1,2})<JS(pts,class,Archive_x{3,1}) 
                                    Archive_x{3,1}=array_3{1,2};
                    end
             end
             if m==0
                    array_3{1,2}(2)=modmatrix(4,N4);
                    N4=N4+1;
                    if LR(pts,class,array_3{1,2})<LR(pts,class,Archive_x{4,1}) 
                                    Archive_x{4,1}=array_3{1,2};
                    end
             end       
                    
            break
        end
            
    end
end

     for  i = 1:1:measure
           Archive_x{i,1}= sort(Archive_x{i,1},2);       
    end


    for i = 1:1:measure
        C_x{t,i}=Archive_x{i,1};
    end
end

%%
for i = 1:1:measure
    [~, loc(i,:)] = sort(par_pbest_mut(i,:),2, 'ascend');
    for j = 1:1:pardata
        temp1{i,j}= par_pbest_x{i,loc(i,j)};
    end
end   
% solution=cell2mat(Archive_x);
solution=Archive_x;

% B_x
% C_x=cell2mat(C_x)
% Pareto_x
    %% Time End
    
    Time=toc; 
    save all
SaveName=[FileName,'_',num2str(ParticleNumber),'_',num2str(IterationNumber),'.mat'];
% save(SaveName,'solution','Value','Time');
save(SaveName,'solution');
end

